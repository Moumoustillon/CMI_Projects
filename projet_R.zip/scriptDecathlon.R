library("Rcmdr")
library("FactoMineR")

str(Decathlon)

Decathlon<-read_excel("C:/Users/Documents/CMI/L1 S2/Projet Ingénierie/Projet_R/Seance3/Decathlon.xlsx")
Decathlon<-data.frame(Decathlon)

row.names(Decathlon) <- Decathlon$Obs
Decathlon$Obs <- NULL

save("Decathlon", file = "C:/Users/mailm/OneDrive - Université paris nanterre/Documents/CMI/L1 S2/Projet Ingénierie/projet_R/Seance3/DECATHLON.RData")

###ACP###
#COMMANDE CLEES#

#VECTEUR DES VARIABLES UTILISEES#

Decathlon.PCA <- Decathlon[, c("X100m", "Longueur", "Poids", "Hauteur", "X400m", "X110m.Obstacle", "Disque", "Perche", "Javelot", "X1500m", "Rang", "Points", "Competition")]

#LANCER LA PROCEDURE#
res <- PCA(Decathlon.PCA, scale.unit = TRUE, ncp = 10, quali.sup = c(13:13), quanti.sup=c(11:12), ind.sup = c(1:5), graph = FALSE)
res

#RESUME DES RESULTATS#
summary(res, nb.dec = 3, nbelements = 10, nbind = 41, ncp = 10, file = "")

POIDS<-Decathlon[, c("Poids")]
BASEBIS<-data.frame(POIDS)
str(BASEBIS)


#GRAPHIQUE INDIVIDUS#
print(plot.PCA(res, axes = c(1,2), choix = "ind", 
	habillage = "none", col.ind.sup = "blue", 
	col.quali="magenta", label = c("ind", "ind.sup", "quali")
	, new.plot = FALSE, title = "OUL"))

#GRAPHIQUE VARIABLES#
print(plot.PCA(res, axes = c(1,2), choix = "var", 
	col.var = "black", col.quanti.sup ="blue", 
	label = c("var", "quanti.sup"), lim.cos2.var = 0,
	title = ""))


res$eig
res$ind.sup

#correlation et p.value#
dimdesc(res, axes = 1:2, proba = 0.5)
condes(Decathlon, num.var = 1, proba = 0.05)
catdes(Decathlon, num.var=13, proba=0.05)
plotellipses(res,13)

install.packages("factoextra")
library("factoextra")






