library("Rcmdr")
library("FactoMineR")
library("factoextra")
library("readxl")
library(ggplot2)

setwd("C:/met ton adresse de dossier")
getwd()

pokemon<-read_excel("C:/met ton adresse de dossier/DBpokemon.xlsx")
pokemon<-data.frame(pokemon)
str(pokemon)

names(pokemon)

#choix colonnes quantitatives
vars <- c("PV", "Attaque", "Défense", "Attaque_spéciale", "Défense_spéciale", "Vitesse", "Taille", "Poids", "Experience_base", "Taux_capture", "Bonheur_base")

library(factoextra) # Charge la librairie factoextra

# Exécution de l'ACP
resultat_acp <- PCA(pokemon[,vars], scale.unit=TRUE, graph=F)

# Affichage des valeurs propres
fviz_eig(resultat_acp, addlabels=TRUE, ylim=c(0,50))

# Affichage des corrélations entre les variables et les axes
fviz_pca_var(resultat_acp, col.var="contrib", repel=TRUE)

# Effectuer une ACP sur les variables numériques de la base de données
res.acp <- PCA(pokemon[vars], graph = FALSE)

# Afficher les valeurs propres
res.acp$eig
pca_pokemon <- PCA(pokemon[,vars], graph = FALSE)
summary(resultat_acp)

names(pokemon[vars])
colMeans(pokemon[vars])
mean(nom_de_la_variable[, c(1, 2)])

summary(pokemon[vars])








